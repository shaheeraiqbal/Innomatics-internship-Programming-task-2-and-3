from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
#from flask import session

from werkzeug.security import generate_password_hash, check_password_hash
from models import db, User, URL, generate_short_code
from urllib.parse import urlparse
import os

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key-change-in-production'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///url_shortener.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize extensions
db.init_app(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'
login_manager.login_message = 'Please log in to access this page.'

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

def validate_username(username):
    """Validate username length (5-9 characters)"""
    if len(username) < 5 or len(username) > 9:
        return False, "Username must be between 5 to 9 characters long"
    return True, ""

def validate_url(url):
    """Validate URL format"""
    try:
        result = urlparse(url)
        if not all([result.scheme, result.netloc]):
            return False, "Please enter a valid URL with http:// or https://"
        if result.scheme not in ['http', 'https']:
            return False, "URL must start with http:// or https://"
        return True, ""
    except Exception:
        return False, "Please enter a valid URL"

# Routes
@app.route('/')
def home():
    """Home page - redirects to login if not authenticated, else dashboard"""
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    return render_template('home.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    """Signup page with username validation"""
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username').strip()
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        
        # Validate username length
        is_valid, message = validate_username(username)
        if not is_valid:
            flash(message, 'danger')
            return render_template('signup.html')
        
        # Check if username already exists
        existing_user = User.query.filter_by(username=username).first()
        if existing_user:
            flash('This username already exists. Please choose another one.', 'danger')
            return render_template('signup.html')
        
        # Check if passwords match
        if password != confirm_password:
            flash('Passwords do not match!', 'danger')
            return render_template('signup.html')
        
        # Check password length
        if len(password) < 6:
            flash('Password must be at least 6 characters long.', 'danger')
            return render_template('signup.html')
        
        # Create new user
        hashed_password = generate_password_hash(password)
        new_user = User(username=username, password=hashed_password)
        
        try:
            db.session.add(new_user)
            db.session.commit()
            flash('Account created successfully! Please login.', 'success')
            return redirect(url_for('login'))
        except Exception as e:
            db.session.rollback()
            flash('An error occurred. Please try again.', 'danger')
            return render_template('signup.html')
    
    return render_template('signup.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    """Login page"""
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username').strip()
        password = request.form.get('password')
        
        user = User.query.filter_by(username=username).first()
        
        if user and check_password_hash(user.password, password):
            login_user(user)
            next_page = request.args.get('next')
            return redirect(next_page) if next_page else redirect(url_for('dashboard'))
        else:
            flash('Invalid username or password', 'danger')
    
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    """Logout user"""
    logout_user()
    flash('You have been logged out.', 'info')
    return redirect(url_for('home'))

@app.route('/dashboard', methods=['GET', 'POST'])
@login_required
def dashboard():
    """Main dashboard for URL shortening"""
    short_url = None
    
    if request.method == 'POST':
        original_url = request.form.get('url').strip()
        
        # Validate URL
        is_valid, message = validate_url(original_url)
        if not is_valid:
            flash(message, 'danger')
            return redirect(url_for('dashboard'))
        
        # Generate unique short code
        max_attempts = 10
        short_code = None
        for _ in range(max_attempts):
            code = generate_short_code()
            existing = URL.query.filter_by(short_code=code).first()
            if not existing:
                short_code = code
                break
        
        if not short_code:
            flash('Could not generate unique short code. Please try again.', 'danger')
            return redirect(url_for('dashboard'))
        
        # Create URL entry
        new_url = URL(
            original_url=original_url,
            short_code=short_code,
            user_id=current_user.id
        )
        
        try:
            db.session.add(new_url)
            db.session.commit()
            short_url = f"{request.host_url}{short_code}"
            flash('URL shortened successfully!', 'success')
        except Exception as e:
            db.session.rollback()
            flash('An error occurred. Please try again.', 'danger')
            return redirect(url_for('dashboard'))
    
    # Get user's URLs for display
    user_urls = URL.query.filter_by(user_id=current_user.id).order_by(URL.created_at.desc()).all()
    return render_template('dashboard.html', user_urls=user_urls, short_url=short_url)
@app.route('/<short_code>')
def redirect_to_url(short_code):
    """Redirect to original URL using short code"""
    url_entry = URL.query.filter_by(short_code=short_code).first()
    
    if url_entry:
        url_entry.clicks += 1
        db.session.commit()
        return redirect(url_entry.original_url)
    
    flash('URL not found', 'danger')
    return redirect(url_for('home'))

@app.route('/delete/<int:url_id>', methods=['POST'])
@login_required
def delete_url(url_id):
    """Delete a shortened URL"""
    url_entry = URL.query.get_or_404(url_id)
    
    # Check if the URL belongs to the current user
    if url_entry.user_id != current_user.id:
        flash('You do not have permission to delete this URL', 'danger')
        return redirect(url_for('dashboard'))
    
    try:
        db.session.delete(url_entry)
        db.session.commit()
        flash('URL deleted successfully', 'success')
    except Exception as e:
        db.session.rollback()
        flash('An error occurred. Please try again.', 'danger')
    
    return redirect(url_for('dashboard'))

@app.route('/api/shorten', methods=['POST'])
@login_required
def api_shorten():
    """API endpoint for URL shortening"""
    data = request.get_json()
    if not data or 'url' not in data:
        return jsonify({'error': 'URL is required'}), 400
    
    original_url = data['url'].strip()
    
    # Validate URL
    is_valid, message = validate_url(original_url)
    if not is_valid:
        return jsonify({'error': message}), 400
    
    # Generate unique short code
    max_attempts = 10
    short_code = None
    for _ in range(max_attempts):
        code = generate_short_code()
        existing = URL.query.filter_by(short_code=code).first()
        if not existing:
            short_code = code
            break
    
    if not short_code:
        return jsonify({'error': 'Could not generate unique short code'}), 500
    
    # Create URL entry
    new_url = URL(
        original_url=original_url,
        short_code=short_code,
        user_id=current_user.id
    )
    
    try:
        db.session.add(new_url)
        db.session.commit()
        short_url = f"{request.host_url}{short_code}"
        return jsonify({
            'original_url': original_url,
            'short_url': short_url,
            'short_code': short_code
        }), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': 'Database error'}), 500

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        print("=" * 60)
        print("🚀 URL Shortener Application")
        print("=" * 60)
        print("✅ Database initialized")
        print(f"🌐 Server starting at: http://127.0.0.1:5000")
        print("=" * 60)
        print("📋 Available Routes:")
        print("  /              - Home page")
        print("  /signup        - User registration")
        print("  /login         - User login")
        print("  /dashboard     - Main dashboard (requires login)")
        print("  /<short_code>  - Redirect to original URL")
        print("=" * 60)
    
    app.run(debug=True, host='127.0.0.1', port=5000)