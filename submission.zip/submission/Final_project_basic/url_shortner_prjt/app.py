from flask import Flask, render_template, request, redirect, jsonify, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from database import db, URLMapping
from models import URLValidator
import os
from datetime import datetime

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key-here-change-in-production'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///urls.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize database
db.init_app(app)

# Create tables
with app.app_context():
    db.create_all()

@app.route('/', methods=['GET', 'POST'])
def index():
    """Home page - URL shortening interface"""
    short_url = None
    original_url = None
    
    if request.method == 'POST':
        original_url = request.form.get('original_url', '').strip()
        
        if not original_url:
            flash('Please enter a URL', 'error')
        elif not URLValidator.is_valid_url(original_url):
            flash('Please enter a valid URL (e.g., https://example.com)', 'error')
        else:
            # Normalize URL
            original_url = URLValidator.normalize_url(original_url)
            
            # Check if URL already exists
            existing = URLMapping.query.filter_by(original_url=original_url).first()
            
            if existing:
                short_url = request.host_url + existing.short_code
            else:
                # Create new short URL
                new_mapping = URLMapping(original_url=original_url)
                db.session.add(new_mapping)
                db.session.commit()
                short_url = request.host_url + new_mapping.short_code
            
            flash('URL shortened successfully!', 'success')
    
    return render_template('index.html', short_url=short_url, original_url=original_url)

@app.route('/history')
def history():
    """Display history of all shortened URLs"""
    urls = URLMapping.query.order_by(URLMapping.created_at.desc()).all()
    
    # Add full short URL to each mapping
    for url in urls:
        url.full_short_url = request.host_url + url.short_code
    
    return render_template('history.html', urls=urls)

@app.route('/<short_code>')
def redirect_to_url(short_code):
    """Redirect short code to original URL"""
    mapping = URLMapping.query.filter_by(short_code=short_code).first()
    
    if mapping:
        return redirect(mapping.original_url)
    else:
        flash('Short URL not found', 'error')
        return redirect(url_for('index'))

@app.route('/api/shorten', methods=['POST'])
def api_shorten():
    """API endpoint for URL shortening"""
    data = request.get_json()
    
    if not data or 'url' not in data:
        return jsonify({'error': 'No URL provided'}), 400
    
    original_url = data['url'].strip()
    
    if not URLValidator.is_valid_url(original_url):
        return jsonify({'error': 'Invalid URL'}), 400
    
    original_url = URLValidator.normalize_url(original_url)
    
    # Check if URL already exists
    existing = URLMapping.query.filter_by(original_url=original_url).first()
    
    if existing:
        short_code = existing.short_code
    else:
        new_mapping = URLMapping(original_url=original_url)
        db.session.add(new_mapping)
        db.session.commit()
        short_code = new_mapping.short_code
    
    short_url = request.host_url + short_code
    
    return jsonify({
        'original_url': original_url,
        'short_url': short_url,
        'short_code': short_code
    })

@app.route('/api/urls', methods=['GET'])
def api_get_urls():
    """API endpoint to get all URLs"""
    urls = URLMapping.query.order_by(URLMapping.created_at.desc()).all()
    
    result = []
    for url in urls:
        result.append({
            'id': url.id,
            'original_url': url.original_url,
            'short_url': request.host_url + url.short_code,
            'short_code': url.short_code,
            'created_at': url.created_at.isoformat() if url.created_at else None
        })
    
    return jsonify(result)

if __name__ == '__main__':
    app.run(debug=True)