import re
from urllib.parse import urlparse
import validators

class URLValidator:
    @staticmethod
    def is_valid_url(url):
        """Validate URL format"""
        # Check if URL starts with http:// or https://
        if not url.startswith(('http://', 'https://')):
            url = 'https://' + url
        
        # Use validators library for robust validation
        return validators.url(url)
    
    @staticmethod
    def normalize_url(url):
        """Ensure URL has proper protocol"""
        if not url.startswith(('http://', 'https://')):
            url = 'https://' + url
        return url
    
    @staticmethod
    def extract_domain(url):
        """Extract domain from URL"""
        parsed = urlparse(url)
        return parsed.netloc