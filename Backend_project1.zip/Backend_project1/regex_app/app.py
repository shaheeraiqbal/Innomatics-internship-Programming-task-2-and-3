from flask import Flask, render_template, request
import re

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def home():
    matches = []
    highlighted_text = ""
    error = ""

    if request.method == "POST":
        test_string = request.form.get("test_string", "")
        regex_pattern = request.form.get("regex", "")
        ignore_case = request.form.get("ignore_case")

        flags = 0
        if ignore_case:
            flags |= re.IGNORECASE

        try:
            pattern = re.compile(regex_pattern,flags)
            matches = pattern.findall(test_string)

            # Highlight matches
            highlighted_text = pattern.sub(
                r"<span class='highlight'>\g<0></span>",
                test_string
            )

        except re.error:
            error = "Invalid Regular Expression"

    return render_template(
        "index.html",
        matches=matches,
        highlighted_text=highlighted_text,
        error=error
    )

if __name__ == "__main__":
    app.run(debug=True,port=5000)
